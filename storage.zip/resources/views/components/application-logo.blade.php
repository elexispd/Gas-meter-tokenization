<img src="{{ asset('dist/img/logo_entak.jpg') }}" alt="entak logo" width="150">
