<footer class="main-footer text-center">
    <strong class="text-center">Copyright &copy; 2016-@php echo date("Y")  @endphp <a href="">Entak Energy LTD.</a>.</strong>
    All rights reserved.
</footer>

<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content -->
</aside>
</div>



