<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <section class="content">
            <div class="container-fluid">
                <h3 class="display-5 pt-3">Search Payment</h3>

                <div class="text-center">
                    <?php echo $__env->make('includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="mt-5">
                    <h4 class="text-center display-5">Search By Meter Number</h4>
                    <div class="row">
                        <div class="col-md-8 offset-md-2">

                            <form action="<?php echo e(route('payment.result')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="search" name="meter_number" class="form-control form-control-lg" placeholder="Type Meter Number here..." autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-lg btn-primary">
                                            <i class="fa fa-search"></i> Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="mt-5">
                    <h4 class="text-center display-5">Search By Order ID</h4>
                    <div class="row">
                        <div class="col-md-8 offset-md-2">
                            <form action="<?php echo e(route('payment.result')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                    <input type="search" name="order_id" class="form-control form-control-lg" placeholder="Type Order ID here..." autocomplete="off">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-lg btn-primary">
                                            <i class="fa fa-search"></i> Search
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


                <div class="mt-5">
                    <h4 class="text-center display-5">Search By Range & Status</h4>
                </div>
                <form action="<?php echo e(route('payment.result')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-10 offset-md-1">
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group">
                                        <label>From:</label>
                                        <input type="date" class="form-control" name="from" id="from">
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <label>To:</label>
                                        <input type="date" class="form-control" name="to" id="to">
                                    </div>
                                </div>

                                <div class="col-6">
                                    <div class="form-group">
                                        <label>Status</label>
                                        <select name="status" id="status" class="form-control" name="status">
                                            <option value=""></option>
                                            <option value="all">All</option>
                                            <option value="0">Initialized</option>
                                            <option value="1">Paid</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="col-6 mx-auto">
                                <div class="form-group text-center">
                                    <button type="submit" class="btn btn-lg btn-primary">
                                        <i class="fa fa-search"></i> Search
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\promise\entak_portal\resources\views/payments/search-payment.blade.php ENDPATH**/ ?>