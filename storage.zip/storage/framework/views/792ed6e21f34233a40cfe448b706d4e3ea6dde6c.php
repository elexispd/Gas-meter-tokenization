<footer class="main-footer text-center">
    <strong class="text-center">Copyright &copy; 2016-<?php echo date("Y")  ?> <a href="">Entak Energy LTD.</a>.</strong>
    All rights reserved.
</footer>

<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content -->
</aside>
</div>



<?php /**PATH C:\Users\HP\Documents\promise\entak_portal\resources\views/includes/footer.blade.php ENDPATH**/ ?>