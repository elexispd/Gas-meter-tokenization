<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Pricing</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Pricing</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Custom Content -->
                    <div class="card">
                        <?php if(auth()->user()->is_super_admin): ?>
                            <div class="card-header">
                                <h3 class="card-title">List of Pricing</h3>
                            </div>
                            <div class="card-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>S/N</th>
                                                <th>Country</th>
                                                <th>Price</th>
                                                <th>Status</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($price->country); ?> </td>
                                                <td><?php echo e($price->price); ?>  </td>
                                                <td>
                                                    <?php if($price->status): ?>
                                                        <span class="badge bg-success">Active</span>
                                                    <?php else: ?>
                                                    <span class="badge bg-danger">Old</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($price->created_at->diffForHumans()); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>S/N</th>
                                            <th>Country</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                        </tr>
                                    </tfoot>
                                </table>


                            </div>
                         <?php else: ?>
                         <div class="card-body">

                            <div class="col-lg-12 text-center">
                                 <img src="<?php echo e(asset('dist/img/plant.png')); ?>" alt="plant" srcset="" style="" >
                                 <h5 class="mt-3">Dear Esteem Customer, Our current price for 1m<sup>3</sup> of LPG is
                                    <?php if($prices && count($prices) > 0): ?>
                                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="price-block">
                                                <strong>
                                                    <?php if($price->country == "Nigeria"): ?>
                                                        NGN
                                                    <?php elseif($price->country == "Cameroon"): ?>
                                                        XAF
                                                    <?php else: ?>
                                                        GHN
                                                    <?php endif; ?>
                                                    <?php echo e($price->price); ?>

                                                </strong>
                                            </div>
                                            <br> <!-- Optional: Add a line break between each price -->
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>



                                </h5>
                            </div>
                         </div>
                        <?php endif; ?>
                    </div>
                    <!-- /.Custom Content -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
    </script>


</div>s




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\promise\entak_portal\resources\views/prices/index.blade.php ENDPATH**/ ?>