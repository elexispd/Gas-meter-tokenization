<?php if(session('alert')): ?>
    <?php if(session('alert')['type'] == "success"): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('alert')['message']); ?>

        </div>
    <?php else: ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('alert')['message']); ?>

        </div>
    <?php endif; ?>

<?php endif; ?>

<?php /**PATH C:\Users\HP\Documents\promise\entak_portal\resources\views/includes/alert.blade.php ENDPATH**/ ?>