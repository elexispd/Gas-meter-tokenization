<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Payment Record</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Payments</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Custom Content -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">List of payments</h3>
                        </div>
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>S/N</th>
                                        <th>Consumer</th>
                                        <th>Quantity</th>
                                        <th>Amount</th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins', auth()->user())): ?>
                                        <th>Currency</th>
                                        <th>Channel</th>
                                        <?php endif; ?>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php
                                        $countryTotals = []; // Initialize an array to store totals for each country
                                    ?>
                                    <?php if(isset($payment)): ?> <!-- Check if $payment variable is set -->

                                        <tr>
                                            <td>1</td> <!-- Assuming it's just one payment -->
                                            <td><?php echo e($payment->user->first_name); ?> <?php echo e($payment->user->last_name); ?></td>
                                            <td><?php echo e($payment->quantity); ?></td>
                                            <td><?php echo e(number_format($payment->response['data']['amount'], 2)); ?></td>
                                            <td><?php echo e($payment->response["data"]["currency"]); ?></td>
                                            <td class="text-capitalize"><?php echo e($payment->response["data"]["channel"]); ?></td>
                                            <td>
                                                <?php if($payment->status == 0): ?>
                                                    <span class="badge bg-warning text-capitalize"><?php echo e($payment->response["data"]["status"]); ?></span>
                                                <?php elseif($payment->status == 1): ?>
                                                    <span class="badge bg-success text-capitalize"><?php echo e($payment->response["data"]["status"]); ?></span>

                                                <?php else: ?>
                                                    <span class="badge bg-warning"><?php echo e($payment->response["data"]["status"]); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($payment->created_at); ?></td>
                                        </tr>
                                    <?php elseif(isset($payments)): ?> <!-- Check if $payments variable is set -->

                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td> <!-- Use $loop->iteration to get the iteration count -->
                                                <td><?php echo e($payment->user->first_name); ?> <?php echo e($payment->user->last_name); ?></td>
                                                <td><?php echo e($payment->quantity); ?></td>
                                                <td><?php echo e(number_format($payment->amount , 2)); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins', auth()->user())): ?>

                                                    <td><?php echo e($payment->response["data"]["currency"]); ?></td>
                                                    <td><?php echo e($payment->response["data"]["channel"]); ?></td>
                                                <?php endif; ?>

                                                <td>
                                                    <?php if($payment->status == 0): ?>
                                                        
                                                        <span class="badge bg-warning text-capitalize"><?php echo e($payment->response["data"]["status"]); ?></span>
                                                    <?php elseif($payment->status == 1): ?>
                                                        <span class="badge bg-success"> <?php echo e($payment->response["data"]["status"]); ?></span>
                                                    <?php else: ?>
                                                        <span class="badge bg-info"><?php echo e($payment->response["data"]["status"]); ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($payment->created_at); ?></td>
                                            </tr>
                                            <?php
                                                // Calculate totals for each country
                                                $country = $payment->user->plants->first()->country;
                                                if (!isset($countryTotals[$country])) {
                                                    $countryTotals[$country] = ['quantity' => 0, 'total' => 0];
                                                }
                                                $countryTotals[$country]['quantity'] += $payment->quantity;
                                                $countryTotals[$country]['total'] += $payment->amount;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>


                                </tbody>
                                <tfoot>
                                    <?php $__currentLoopData = $countryTotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country => $totals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th>Total </th>
                                            <th><?php echo e($country); ?></th>
                                            <th><?php echo e($totals['quantity']); ?></th>
                                            <th></th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admins', auth()->user())): ?>
                                                <th></th>
                                                <th></th>
                                            <?php endif; ?>
                                            <th></th>
                                            <th><?php echo e(number_format($totals['total'], 2)); ?></th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <!-- /.Custom Content -->
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <script>
        $(function () {
            $("#example1").DataTable({
            "responsive": true, "lengthChange": false, "autoWidth": false,
            "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false,
            "responsive": true,
            });
        });
    </script>


</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\promise\entak_portal\resources\views/payments/history.blade.php ENDPATH**/ ?>