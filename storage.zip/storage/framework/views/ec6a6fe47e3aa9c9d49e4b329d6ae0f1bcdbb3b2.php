<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meter Token Purchase Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        p {
            color: #666; /* Base gray color */
            margin-bottom: 10px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* Use a common sans-serif font */
            font-size: 16px; /* Adjust font size as needed */
            line-height: 1.6; /* Adjust line height for better readability */
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.2); /* Add subtle shadow effect */
        }
        .info {
            margin-top: 20px;
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 5px;
        }
        .info p {
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div style="text-align: center;">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'w-20 h-20 fill-current text-gray-500']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-20 h-20 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
        <h3 style="text-align: center;">Meter Token Purchase Confirmation</h3>
        <p>Hello <?php echo e($name); ?> ,</p>
        <div class="info">
            <p><strong>Meter Token:</strong> <?php echo e($token); ?></p>
            <p><strong>Price:</strong> <?php echo e($price); ?></p>
            <p><strong>Quantity:</strong> <?php echo e($quantity); ?> </p>
        </div>
        <p>Thank you for your purchase. If you have any questions, feel free to contact us at <a href="mailto:info@entakgroup.com">info@entakgroup.com</a>.</p>
        <p>Best regards,<br> <a href="http://entakenergy.com.ng">Entak Energy LTD.</a> </p>
    </div>
</body>
</html>
<?php /**PATH C:\Users\HP\Documents\promise\entak_portal\resources\views/emails/token.blade.php ENDPATH**/ ?>